
recyletresh - v5 2022-06-03 6:12pm
==============================

This dataset was exported via roboflow.ai on June 3, 2022 at 9:13 AM GMT

It includes 1670 images.
Kind-of-tresh are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 244x244 (Stretch)

The following augmentation was applied to create 3 versions of each source image:
* 50% probability of horizontal flip
* 50% probability of vertical flip
* Random shear of between -15° to +15° horizontally and -15° to +15° vertically


